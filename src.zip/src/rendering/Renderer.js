import Camera from "../camera/Camera.js";
import HandTracker from "../mediapipe/HandTracker.js";

import Dot from "../ui/Dot.js";
import Line from "../ui/Line.js";
import DistanceMeter from "../ui/DistanceMeter.js";

import Theme from "../ui/Theme.js";
import Signals from "../signals/Signals.js";

import SignalMapper from "../signals/SignalMapper.js";

export default class Renderer {

    constructor(p) {

        console.log("Renderer created");

        this.p = p;

        this.cameraBuffer = p.createGraphics(
            p.width,
            p.height
        );

        this.sceneBuffer = p.createGraphics(
            p.width,
            p.height
        );

        this.cameraFX = p.createGraphics(
            80,
            45
        );

        this.cameraFX.noSmooth();

        this.finalBuffer.pixelDensity(1);
        this.buffer.pixelDensity(1);

        this.smoothedHands = [];
        this.signals = new Signals();
        this.mapper = new SignalMapper(
            p,
            this.signals
        );

        // UI
        this.dot = new Dot(p);
        this.line = new Line(p);
        this.distanceMeter = new DistanceMeter(p);

        // Camera
        this.camera = new Camera();
        this.ready = false;

        this.camera.start().then(async () => {

            this.ready = true;

            console.log("Camera Ready");

            this.handTracker = new HandTracker(
                this.camera.getVideo()
            );

            await this.handTracker.init();

        });

    }

    render() {

        this.p.background(0);

        if (!this.ready) return;

        const video = this.camera.getVideo();

        if (video.readyState < 2) return;

        // Draw camera into camera buffer
        this.drawCamera(video);

        // Get tracking
        const results = this.handTracker.update();

        // Update signals
        this.mapper.update();

        // Build final frame
        this.finalBuffer.clear();

        // Camera first
        this.finalBuffer.image(
            this.buffer,
            0,
            0
        );

        // UI second
        this.drawUI(results);

        // Present final image
       this.p.push();

        this.p.translate(this.p.width, 0);
        this.p.scale(-1, 1);

       // Pixelate camera
        this.cameraFX.clear();

        this.cameraFX.image(
            this.buffer,
            0,
            0,
            this.cameraFX.width,
            this.cameraFX.height
        );

        // Replace the camera layer
        this.finalBuffer.clear();

        this.finalBuffer.image(
            this.cameraFX,
            0,
            0,
            this.finalBuffer.width,
            this.finalBuffer.height
        );

        // Draw UI back on top
        this.drawUI(results);

        // Mirror final scene
        this.p.push();

        this.p.translate(this.p.width, 0);
        this.p.scale(-1, 1);

        this.p.noSmooth();

        this.p.image(
            this.finalBuffer,
            0,
            0
        );

        this.p.pop();

    }

   resize() {

        this.cameraBuffer.resizeCanvas(
            this.p.width,
            this.p.height
        );

        this.sceneBuffer.resizeCanvas(
            this.p.width,
            this.p.height
        );

    }

    drawCamera(video) {

        const g = this.buffer;

        g.clear();

        const vw = video.videoWidth;
        const vh = video.videoHeight;

        const scale = Math.max(
            g.width / vw,
            g.height / vh
        );

        const w = vw * scale;
        const h = vh * scale;

        const x = (g.width - w) * 0.5;
        const y = (g.height - h) * 0.5;

        g.drawingContext.drawImage(
            video,
            x,
            y,
            w,
            h
        );

        g.colorMode(
            this.p.HSB,
            360,
            100,
            100,
            255
        );

        g.noStroke();

        g.fill(
            this.mapper.overlay.hue,
            100,
            20,
            this.mapper.overlay.opacity
        );

        g.rect(
            0,
            0,
            g.width,
            g.height
        );

        g.colorMode(this.p.RGB);

    }

    drawHands(results) {

        if (!results.landmarks?.length) return;

        results.landmarks.forEach((hand, handIndex) => {

            if (!this.smoothedHands[handIndex]) {

                this.smoothedHands[handIndex] = hand.map(point => ({
                    x: point.x,
                    y: point.y
                }));

            }

            const smoothValue = 0.6;

            hand.forEach((point, pointIndex) => {

                const smooth = this.smoothedHands[handIndex][pointIndex];

                smooth.x = this.p.lerp(
                    smooth.x,
                    point.x,
                    smoothValue
                );

                smooth.y = this.p.lerp(
                    smooth.y,
                    point.y,
                    smoothValue
                );

            });

            const thumb = this.smoothedHands[handIndex][4];
            const index = this.smoothedHands[handIndex][8];

            let tx = thumb.x * this.p.width;
            let ty = thumb.y * this.p.height;

            let ix = index.x * this.p.width;
            let iy = index.y * this.p.height;

        

            const distance = this.p.dist(
                tx,
                ty,
                ix,
                iy
            );

            this.signals.hand[handIndex].pinch = this.p.map(
                distance,
                20,     // fingers touching
                250,    // fingers fully open
                0,
                1,
                true
            );

            this.line.draw(
                tx,
                ty,
                ix,
                iy
            );

            this.dot.draw(
                tx,
                ty
            );

            this.dot.draw(
                ix,
                iy
            );

            this.distanceMeter.signal =
                this.signals.hand[handIndex].pinch;


            this.distanceMeter.draw(
                tx,
                ty,
                ix,
                iy
            );

        
        });

    }

    drawUI(results) {

        this.dot.g = this.finalBuffer;
        this.line.g = this.finalBuffer;
        this.distanceMeter.g = this.finalBuffer;

        if (results) {
            this.drawHands(results);
        }

    }

}