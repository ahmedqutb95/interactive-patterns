import Theme from "./Theme.js";

export default class DistanceMeter {

    constructor(p) {
        this.p = p;
        this.g = p;
        this.signal = 0;
    }

    draw(x1, y1, x2, y2) {

        const g = this.g;
        const p = this.p;


        const pinch = this.signal;

        const mx = (x1 + x2) * 0.5;
        const my = (y1 + y2) * 0.5;

        const pillWidth = 64;
        const pillHeight = 32;
        const radius = 16;

        g.push();

        // Background
        g.rectMode(this.p.CENTER);
        g.noStroke();
        g.fill(0, 180);

        g.rect(
            mx,
            my,
            pillWidth,
            pillHeight,
            radius
        );

        // Border
        g.noFill();
        g.stroke(Theme.colors.primary);
        g.strokeWeight(Theme.stroke.normal);

        g.rect(
            mx,
            my,
            pillWidth,
            pillHeight,
            radius
        );

        // Text

        g.noStroke();
        g.fill(Theme.colors.primary);

        g.textAlign(p.CENTER, p.CENTER);
        g.textSize(18);

        g.push();
        g.translate(mx, my);
        
        g.scale(-1, 1);

        g.text(
            pinch.toFixed(2),
            0,
            0
        );

        g.pop();

        g.pop();

    }

}