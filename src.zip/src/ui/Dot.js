import Theme from "./Theme.js";

export default class Dot {

    constructor(p) {
        this.p = p;
        this.g = p;
        this.scale = 1;
    }

    draw(x, y) {

        const g = this.g;

        // Outer circle
        g.fill(0, 0, 0, 70);
        g.stroke(Theme.colors.primary);
        g.strokeWeight(Theme.stroke.normal);
        g.circle(
            x,
            y,
            Theme.radius.dot * this.scale * 12
        );

        // Inner translucent fill
        g.noStroke();
        g.fill(255, 255, 255, );
        g.circle(
            x,
            y,
            Theme.radius.dot * this.scale * 2
        );

        // Center dot
        g.fill(Theme.colors.primary);
        g.circle(
            x,
            y,
            Theme.radius.dot * this.scale * 0.22
        );

    }

}