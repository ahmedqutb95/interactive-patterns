import Theme from "./Theme.js";

export default class Line {

    constructor(p) {
        this.p = p;
        this.g = p;
    }

    draw(x1, y1, x2, y2) {

        const g = this.g;

        g.stroke(Theme.colors.primary);
        g.strokeWeight(Theme.stroke.normal);
        g.noFill();

        g.line(
            x1,
            y1,
            x2,
            y2
        );

    }

}